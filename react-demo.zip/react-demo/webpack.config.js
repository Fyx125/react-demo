module.exports={
	entry:'./index.js',
	output:{
		path:__dirname,
		filename:'bundle.js'
	},
	devServer: {
		port:3030,   //改变端口
		open:true,   //默认打开浏览器
		inline:true   //自动刷新
		// contentBase:'./app'   //指定服务器文件路径
	},
	mode: 'development',
	module:{
		rules:[{
			test:/\.css$/,
			use:['style-loader','css-loader']
		},
		{
			test:/\.js$/,
			use:['react-hot-loader','babel-loader'],
			exclude:/node_modules/
		}
		]
	}
}