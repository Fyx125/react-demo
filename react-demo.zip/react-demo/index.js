import React from 'react'
import ReactDOM from 'react-dom'
import Title from './Title.js'


class Leo extends React.Component{
	constructor(){
		super();
		this.state ={
			msg:'hello react!'
		}
	}
	show(){
		console.log(1);
	}
	render(){
		return (<div>
				<Title setMsg={this.state.msg}/>
				<input type='button' onClick={this.show.bind(this)}/>
			</div>)
	}
}


ReactDOM.render(<Leo/>,document.getElementById('app'));
