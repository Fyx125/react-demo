import React from 'react'
import ReactDOM from 'react-dom'
import Title from './app/Title.js'
import Yeye from './app/Yeye.js'


class Leo extends React.Component{
	constructor(){
		super();
		this.state ={
			a:10,
			b:'1000',
			c:111,
			d:100
		}
	}
	show(){
		this.setState({a:this.state.a+1});  //不能写++
	}
	setD(){
		this.setState({d:1});
	}


	render(){
		return (<div>
				<Title add={this.state.a} a={this.state.a} b={this.state.b} d={this.state.d}/>
				<Yeye/>
				<input type='button' onClick={this.show.bind(this)} value="add"/>
            	<input type='button' onClick={this.setD.bind(this)} value="设置"/>
			</div>);
	}
}


ReactDOM.render(<Leo/>,document.getElementById('app'));
