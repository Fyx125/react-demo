import React from 'react';
import ReactDOM from 'react-dom';
import {PropTypes} from 'prop-types'


class Title extends React.Component {

	//构造函数
	constructor(){
		super();    //要求调用
		this.state={

		}
	}
	//渲染
	render(){
		return (<div>
				<span>{this.props.add}</span>
				<p>{this.props.a}</p>
            	<p>{this.props.b}</p>
            	<p>{this.props.d}</p>
			</div>)
	}
}

//定义组件需要传入参数的属性的类型
//类名.propTypes  只是一个json  key是需要传入的props属性名  v就是对他的限制
Title.propTypes={
	a:PropTypes.number.isRequired,   //定义a属性是一个数字  必传  （去掉isRequired 就不是必传了）
	b:PropTypes.string.isRequired    //定义b属性是一个字符串  必传
}

export default Title;       //向外暴露