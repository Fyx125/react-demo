import React from 'react';
import ReactDOM from 'react-dom';
import {PropTypes} from 'prop-types'
import Sunzi from "./Sunzi";


class Baba extends React.Component {

    //构造函数
    constructor(props,context){
        super();    //要求调用
        console.log(context);
        this.state={

        }
    }
    //渲染
    render(){
        return (<div>
            <h1>爸爸</h1>
            <Sunzi/>
        </div>)
    }
}
Baba.contextTypes={
    c:PropTypes.number.isRequired
};




export default Baba;       //向外暴露