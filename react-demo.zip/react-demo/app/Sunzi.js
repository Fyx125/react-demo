import React from 'react';
import ReactDOM from 'react-dom';
import {PropTypes} from 'prop-types'


class Sunzi extends React.Component {

    //构造函数
    constructor(props,context){
        super();    //要求调用
        console.log(context);
        this.state={

        }
    }
    //渲染
    render(){
        //context  跨级传值
        return (<div>
            <h1>孙子<input type='button' onClick={()=>{this.context.add()}} value="add孙子"/></h1>
            <p>{this.context.c}</p>
        </div>)
    }
}


Sunzi.contextTypes={
    c:PropTypes.number,
    add:PropTypes.func
};

export default Sunzi;       //向外暴露