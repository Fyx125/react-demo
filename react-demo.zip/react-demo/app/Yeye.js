import React from 'react';
import ReactDOM from 'react-dom';
import {PropTypes} from 'prop-types'
import Baba from "./Baba";


class Yeye extends React.Component {

    //构造函数
    constructor(){
        super();    //要求调用
        this.state={
            c:88
        }
    }
    add(){
        this.setState({c:this.state.c+1});  //不能写++
    }
    //得到孩子上下文，这个对象就是现在这个家族体系共享的上下文，将上下文中的a值变成自己状态中的a值
    getChildContext(){
        return {
            c:this.state.c,
            add:this.add.bind(this)
        }
    }
    //渲染
    render(){
        return (<div>
            <h1>爷爷<input type='button' onClick={this.add.bind(this)} value="add爷爷"/></h1>
            <p>{this.state.c}</p>
            <Baba/>
        </div>)
    }
}

//设置child的上下文类型
Yeye.childContextTypes={
    c:PropTypes.number.isRequired,
    add: PropTypes.func.isRequired   //func表示函数
};




export default Yeye;       //向外暴露